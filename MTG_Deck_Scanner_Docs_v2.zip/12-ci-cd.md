# CI/CD (GitHub Actions)

Jobs:
- **backend**: setup Python, install deps, hydrate Scryfall (best-effort), run tests (placeholder).
- **webapp**: setup Node, install, build.

See `.github/workflows/ci.yml` in repo.
