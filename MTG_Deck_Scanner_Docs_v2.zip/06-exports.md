# Export Formats

## MTGA
```
Deck
4 Card Name
...

Sideboard
3 Card Name
...
```

## Moxfield
```
4 Card Name
3 Another
...
```

## Archidekt (CSV-like)
```
Count,Name,Categories
4,Card Name,Mainboard
3,Card Name,Sideboard
```

## TappedOut
```
4 Card Name
...

Sideboard
3 Card Name
...
```
